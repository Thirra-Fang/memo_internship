using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{

    public int health;
    public int damage;
    public float deathtime;
    private Animator anim;
    public bool checkAlive()
    {
        return health > 0;
    }
    // Start is called before the first frame update
    protected void Start()
    {
        anim = GetComponent<Animator>();
    }

    // Update is called once per frame
    protected void Update()
    {
        checkDestroy();
    }
    void checkDestroy()
    {
        if (!checkAlive())
        {
            anim.SetBool("Death",true);
            StartCoroutine(displaydeath());
        }
    }

    public void takeDamage(int damaged)
    {
        health -= damaged;
    }

    IEnumerator displaydeath()
    {
        yield return new WaitForSeconds(deathtime);
        Destroy(gameObject);
    }
}
