using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FootFollowBody : MonoBehaviour
{
    public Transform target;
    private Animator myAnim;
    private Vector3 div = new Vector3(0.093f, -0.299f);
    private Vector3 _div = new Vector3(-0.093f, -0.299f);
    private Vector3 div_jump = new Vector3(0.0f,-0.3883f);
    // Start is called before the first frame update
    void Start()
    {
        transform.position = target.position+div;
        myAnim = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        keepFollow();
        Jump();
    }

    void keepFollow()
    {

        if (target != null)
            if (target.GetComponent<PlayerControl>().getIsGround())
            {
                if (target.rotation[1] == 0)
                {
                    if (transform.position != target.position + div)
                        transform.position = target.position + div;
                }
                else
                    if (transform.position != target.position + _div)
                    transform.position = target.position + _div;
            }
            else
            {
                if (transform.position != target.position + div_jump)
                    transform.position = target.position + div_jump;
            }

        myAnim.SetBool("run", target.GetComponent<PlayerControl>().getIsXSpeed());
        transform.localRotation = Quaternion.Euler(0, 0, 0);
    }
    void Jump()
    {
        myAnim.SetBool("onground", target.GetComponent<PlayerControl>().getIsGround());
    }
}
