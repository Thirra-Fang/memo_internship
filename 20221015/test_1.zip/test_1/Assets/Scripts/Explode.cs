using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Explode : MonoBehaviour
{
    public GameObject firePrefab;
    public Vector2 startSpeed;
    public float delayTime;
    public Vector3 placeDiv;
    private Rigidbody2D rb2D;
    // Start is called before the first frame update
    void Start()
    {
        rb2D = GetComponent<Rigidbody2D>();
        rb2D.velocity = transform.right * startSpeed.x + transform.up * startSpeed.y;
        Invoke("Explo", delayTime);
    }

    // Update is called once per frame
    void Update()
    {
        keepDirection();
    }
    void Explo()
    {
        Instantiate(firePrefab, transform.position+placeDiv, Quaternion.Euler(transform.rotation.x, transform.rotation.y,0));
        Destroy(gameObject);
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {

        if (collision.gameObject.CompareTag("Enemy"))
        {
            Explo();
        }
    }
    private void keepDirection()
    {
        if (Mathf.Abs(rb2D.velocity.x) > 0.01)
        {
            transform.rotation = Quaternion.Euler(transform.rotation.x, transform.rotation.y, 180 / Mathf.PI * Mathf.Atan(rb2D.velocity.y / rb2D.velocity.x));
        }
    }
}
