using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ArrowHit : MonoBehaviour
{
    public GameObject arrowPrefab;
    public GameObject bombPrefab;

    public float attackCycle;
    public float bombCycle;
    public float throwStartTime;

    private bool cd;
    private bool bombCd;
    private Animator anim;
    // Start is called before the first frame update
    void Start()
    {
        transform.localRotation = Quaternion.Euler(0, 180f, 0);
        cd = true;
        bombCd = true;
        anim = GameObject.FindGameObjectWithTag("Player").GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
    }
    
    public void Shoot()
    {
        if (cd)
        { 
            Instantiate(arrowPrefab, transform.position, transform.rotation);
            StartCoroutine(attackPause());
            anim.SetTrigger("Attack");
        }
    }

    public void thowBomb()
    {
        if (bombCd)
        {
            StartCoroutine(throwPause());
            anim.SetTrigger("Throw");
        }
    }
    IEnumerator attackPause()
    {
        cd = false;
        yield return new WaitForSeconds(attackCycle);
        cd = true;
    }
    IEnumerator throwPause()
    {
        bombCd = false;
        yield return new WaitForSeconds(throwStartTime);
        Instantiate(bombPrefab, transform.position, transform.rotation);
        yield return new WaitForSeconds(bombCycle-throwStartTime);
        bombCd = true;
    }
}
