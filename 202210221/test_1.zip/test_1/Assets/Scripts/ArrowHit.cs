using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ArrowHit : MonoBehaviour
{
    public GameObject arrowPrefab;
    public GameObject bombPrefab;

    public float attackCycle;
    public float bombCycle;
    public float throwStartTime;
    public Vector3 lookUpReviseDig;
    public Vector3 lookUpDiv;

    private bool cd;
    private bool bombCd;
    private Animator anim;
    private bool isLookUp;
    // Start is called before the first frame update
    void Start()
    {
        transform.localRotation = Quaternion.Euler(0, 180f, 0);
        cd = true;
        bombCd = true;
        anim = GameObject.FindGameObjectWithTag("Player").GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
    }
    
    public void Shoot()
    {
        if (cd)
        {
            if (!isLookUp)
            {
                Instantiate(arrowPrefab, transform.position, transform.rotation).transform.parent = GameObject.FindGameObjectsWithTag("Refer")[0].transform;
                StartCoroutine(attackPause());
                anim.SetTrigger("Attack");
            }
            else
            {
                Instantiate(arrowPrefab, transform.position+lookUpDiv, 
                    Quaternion.Euler(transform.eulerAngles.x+lookUpReviseDig.x,
                    transform.eulerAngles.y + lookUpReviseDig.y,
                    transform.eulerAngles.z + lookUpReviseDig.z)).transform.parent = GameObject.FindGameObjectsWithTag("Refer")[0].transform;
                StartCoroutine(attackPause());
                anim.SetTrigger("Attack");
            }
        }
    }

    public void thowBomb()
    {
        if (bombCd)
        {
            StartCoroutine(throwPause());
            anim.SetTrigger("Throw");
        }
    }
    public void setLookUp(bool lookup)
    {
        isLookUp = lookup;
    }
    IEnumerator attackPause()
    {
        cd = false;
        yield return new WaitForSeconds(attackCycle);
        cd = true;
    }
    IEnumerator throwPause()
    {
        bombCd = false;
        yield return new WaitForSeconds(throwStartTime);
        Instantiate(bombPrefab, transform.position, transform.rotation).transform.parent = GameObject.FindGameObjectsWithTag("Refer")[0].transform;
        yield return new WaitForSeconds(bombCycle-throwStartTime);
        bombCd = true;
    }
}
