using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerControl : MonoBehaviour
{
    public float runSpeed;
    public float jumpSpeed;
    public Vector3 div_squat;
    public Transform foot;
    public Transform attackControl;
    public Vector3 lookUpShootDiv;
    public float shootEndTime;
    public int health;
    public float invincibleTime;

    private bool playerHasXAxisSpeed;
    private bool isGround;
    private bool isSquat;
    private Rigidbody2D myRigidbody;
    private Animator myAnim;
    private BoxCollider2D myFeet;
    private bool isLookUpShoot;
    private Vector2 boxOriginLoc;
    private bool isIncible;
    private int score;
    private int[] scores;


    public bool getIsXSpeed()
    {
        return playerHasXAxisSpeed;
    }

    public bool getIsGround()
    {
        return isGround;
    }
    public int getScores(int i)
    {
        return scores[i];
    }
    // Start is called before the first frame update
    void Start()
    {
        myRigidbody = GetComponent<Rigidbody2D>();
        myAnim = GetComponent<Animator>();
        myFeet = GetComponent<BoxCollider2D>();
        playerHasXAxisSpeed = false;
        isSquat = false;
        boxOriginLoc = GetComponent<BoxCollider2D>().offset;
        isIncible = false;
        scores = new int[7];
        score = 0;
        CheckScore();
    }

    // Update is called once per frame
    void Update()
    {
        Run();
        Flip();
        CheckGround();
        Jump();
        Squat();
        LookUp();
        CheckOriginLocation();
        CheckAlive();
    }

    void CheckGround()
    {
        isGround = myFeet.IsTouchingLayers(LayerMask.GetMask("Ground"));
        myAnim.SetBool("onground", isGround);
        if (myFeet.IsTouchingLayers(LayerMask.GetMask("DangerousGround")))
        {
            health -= 9;
        }
    }

    void Flip()
    {
        if (playerHasXAxisSpeed)
        {
            if (myRigidbody.velocity.x > 0.1f)
                transform.localRotation = Quaternion.Euler(0, 180, 0);

            if (myRigidbody.velocity.x < -0.1f)
                transform.localRotation = Quaternion.Euler(0, 0, 0);
        }
    }

    void Run()
    {
        if (!isSquat)
        {
            float moveDir = Input.GetAxis("Horizontal");
            Vector2 playerVel = new Vector2(moveDir * runSpeed, myRigidbody.velocity.y);
            myRigidbody.velocity = playerVel;
        }
        playerHasXAxisSpeed = Mathf.Abs(myRigidbody.velocity.x) > 0.1f;
        myAnim.SetBool("run", playerHasXAxisSpeed);
    }

    void Jump()
    {
        if (Input.GetButtonDown("Jump") && isGround && (!isSquat))
        {
            Vector2 jumpVel = new Vector2(0.0f, jumpSpeed);
            myRigidbody.velocity = Vector2.up * jumpVel;
        }
    }
    void Squat()
    {
        if (Input.GetButtonDown("Squat") && isGround)
        {
            isSquat = true;
            changeLocationOfBody(div_squat);
            myRigidbody.velocity = new Vector2(0, 0);
            foot.GetComponent<FootFollowBody>().squat(true);
        }
        if (Input.GetButtonUp("Squat") && isSquat)
        {
            isSquat = false;
            changeLocationOfBody(-div_squat);
            foot.GetComponent<FootFollowBody>().squat(false);
        }
        myAnim.SetBool("isSquat", isSquat);
    }
    void LookUp()
    {
        if (Input.GetButtonDown("LookUp"))
        {
            myAnim.SetBool("isLookUp", true);
            attackControl.GetComponent<PlayerAttack>().shootZone.GetComponent<ArrowHit>().setLookUp(true);
        }
        if (Input.GetButtonUp("LookUp"))
        {
            myAnim.SetBool("isLookUp", false);
            attackControl.GetComponent<PlayerAttack>().shootZone.GetComponent<ArrowHit>().setLookUp(false);
        }
        if ((!isLookUpShoot) && Input.GetButton("LookUp") && Input.GetButton("Attack"))
        {
            changeLocationOfBody(lookUpShootDiv);
            isLookUpShoot = true;
        }
        if (isLookUpShoot && !(Input.GetButton("LookUp") && Input.GetButton("Attack")))
        {
            isLookUpShoot = false;
            StartCoroutine(waitLookUpShootAnim());
        }
        if (isLookUpShoot && (transform.eulerAngles.y - 90) / 90 * Input.GetAxis("Horizontal") < 0)
        {
            StartCoroutine(waitLookUpShootChangeDir());
        }
    }
    void changeLocationOfBody(Vector3 div)
    {
        Vector3 actualDiv = new Vector3(div.x * (transform.eulerAngles.y - 90) / 90, div.y);
        GetComponent<BoxCollider2D>().offset -= new Vector2(actualDiv.x, actualDiv.y);
        transform.position += actualDiv;
        foot.GetComponent<FootFollowBody>().body_div(actualDiv);
    }
    void CheckOriginLocation()
    {
        if ((!isSquat) && (!isLookUpShoot))
        {
            GetComponent<BoxCollider2D>().offset = boxOriginLoc;
            foot.GetComponent<FootFollowBody>().clrDiv();
        }
    }
    IEnumerator waitLookUpShootAnim()
    {
        yield return new WaitForSeconds(shootEndTime);
        changeLocationOfBody(-lookUpShootDiv);
    }
    IEnumerator waitLookUpShootChangeDir() {
        yield return new WaitForSeconds(0.000001f);
        changeLocationOfBody(new Vector3(lookUpShootDiv.x, -lookUpShootDiv.y));
        changeLocationOfBody(lookUpShootDiv);
    }
    public void getDamage()
    {
        if (!isIncible)
        {
            health -= 1;
            StartCoroutine(damageCd());
        }
    }
    IEnumerator damageCd()
    {
        isIncible = true;
        yield return new WaitForSeconds(invincibleTime);
        isIncible = false;
    }
    void CheckAlive()
    {
        if (health < 1)
        {
            SceneManager.LoadScene(2);
        }
    }
    void CheckScore()
    {
        int sco = score;
        for (int i = 6; i >= 0;i--)
        {
            scores[i] = sco % 10;
            sco /= 10;
        }
    }
    public void gainScore(int plusScore)
    {
        score += plusScore;
        CheckScore();
    }
}
