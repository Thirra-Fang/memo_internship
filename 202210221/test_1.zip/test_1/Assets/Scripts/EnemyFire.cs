using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyFire : MonoBehaviour
{   
    public int damage;
    public float time;
    public int damageTimes;

    // Start is called before the first frame update
    void Start()
    {
        Invoke("destr", time);
    }

    // Update is called once per frame
    void Update()
    {

    }
    private void OnTriggerEnter2D(Collider2D collision)
    {

        if (collision.gameObject.CompareTag("Player") && damageTimes > 0)
        {
            Debug.Log("damaged");
            collision.GetComponent<PlayerControl>().getDamage();
            damageTimes--;
        }
    }
    private void destr()
    {
        Destroy(gameObject);
    }
    
}
