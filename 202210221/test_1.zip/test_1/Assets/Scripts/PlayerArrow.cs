using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerArrow : MonoBehaviour
{
    public float speed;
    public int damage;
    public float destroyDistance;

    private Rigidbody2D rb2D;
    private Vector3 startPos;
    // Start is called before the first frame update
    protected void Start()
    {
        startPos = transform.position;
        rb2D = GetComponent<Rigidbody2D>();
        rb2D.velocity = transform.right * speed;
    }

    // Update is called once per frame
    protected void Update()
    {
        float distance = (transform.position - startPos).sqrMagnitude;
        if (distance > destroyDistance)
        {
            Destroy(gameObject);
        }
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Enemy"))
        {
            bool checkAlive = collision.GetComponent<Enemy>().checkAlive();
            collision.GetComponent<Enemy>().takeDamage(damage);
            if (checkAlive)
            {
                Destroy(gameObject);
            }

        }
    }
}
