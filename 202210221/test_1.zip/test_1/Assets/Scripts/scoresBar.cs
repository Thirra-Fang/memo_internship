using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class scoresBar : MonoBehaviour
{
    public int digit;

    private Animator myAnim;
    private GameObject player;
    // Start is called before the first frame update
    void Start()
    {
        myAnim = GetComponent<Animator>();
        player = GameObject.FindWithTag("Player");
    }

    // Update is called once per frame
    void Update()
    {
        checkAnim();
    }
    void checkAnim()
    {
        myAnim.SetInteger("nums", player.transform.GetComponent<PlayerControl>().getScores(digit));
    }
}
