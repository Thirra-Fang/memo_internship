using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemyExplodes : MonoBehaviour
{
    public GameObject firePrefab;
    public Vector2 startSpeed;
    public Vector3 placeDiv;
    public float activeDistance;

    private Rigidbody2D rb2D;
    private GameObject player;
    private bool isActive;
    // Start is called before the first frame update
    void Start()
    {
        player = GameObject.FindWithTag("Player");
        isActive = false;
    }

    // Update is called once per frame
    void Update()
    {
        checkDistance();
    }
    void Explo()
    {
        Instantiate(firePrefab, transform.position + placeDiv, Quaternion.Euler(transform.rotation.x, transform.rotation.y, 0));
        Destroy(gameObject);
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {

        if (collision.gameObject.CompareTag("Player")|| collision.gameObject.CompareTag("Arrows"))
        {
            Explo();
        }
    }
    void checkDistance()
    {
        if (Vector3.Distance(player.transform.position, transform.position) < activeDistance)
        {
            isActive = true;
            rb2D = GetComponent<Rigidbody2D>();
            rb2D.velocity = transform.right * startSpeed.x + transform.up * startSpeed.y;
        }
        if (isActive && Vector3.Distance(player.transform.position, transform.position) > 4 * activeDistance)
        {
            Destroy(gameObject);
        }
    }
}
