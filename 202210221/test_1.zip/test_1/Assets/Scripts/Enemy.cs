using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{

    public int health;
    public int damage;
    public float deathtime;
    public float divTime;
    public Vector3 div_death;
    public float activeDistance;
    public float speed;
    public int killedScore;

    private bool isDead;
    private Vector2 div_death2;

    protected Animator anim;
    protected Rigidbody2D rb2D;
    protected GameObject player;
    protected bool isActive;
    public bool checkAlive()
    {
        return health > 0;
    }
    // Start is called before the first frame update
    protected void Start()
    {
        player = GameObject.FindWithTag("Player");
        anim = GetComponent<Animator>();
        rb2D = GetComponent<Rigidbody2D>();
        div_death2 = div_death;
        isDead = false;
        isActive = false;
    }

    // Update is called once per frame
    protected void Update()
    {
        checkDestroy();
        checkDistance();
    }
    void checkDestroy()
    {
        if ((!checkAlive())&&(!isDead))
        {
            isDead = true;
            if (anim != null)
            {
                anim.SetBool("Death", true);
            }
            StartCoroutine(displaydeath());
            player.transform.GetComponent<PlayerControl>().gainScore(killedScore);
        }
    }

    public void takeDamage(int damaged)
    {
        health -= damaged;
    }

    IEnumerator displaydeath()
    {
        yield return new WaitForSeconds(divTime);
        transform.position += div_death;
        GetComponent<BoxCollider2D>().offset -= div_death2;
        yield return new WaitForSeconds(deathtime-divTime);
        Destroy(gameObject);
    }
    void checkDistance()
    {
        if (Vector3.Distance(player.transform.position, transform.position) < activeDistance)
        {
            isActive = true;
        }
        if(isActive&& Vector3.Distance(player.transform.position, transform.position) > 4*activeDistance)
        {
            Destroy(gameObject);
        }
    }

}
