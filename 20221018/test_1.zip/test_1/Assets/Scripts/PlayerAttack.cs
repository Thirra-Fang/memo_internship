using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerAttack : MonoBehaviour
{
    public int damage;
    public float time;
    public float startTime;
    public Transform shootZone;

    private bool nearCd;
    private bool isNear;
    private Animator anim;
    private PolygonCollider2D coll2D;
    private BoxCollider2D checkZone;
    // Start is called before the first frame update
    void Start()
    {
        anim = GameObject.FindGameObjectWithTag("Player").GetComponent<Animator>();
        coll2D = GetComponent<PolygonCollider2D>();
        checkZone = shootZone.GetComponent<BoxCollider2D>();
        nearCd = true;
    }

    // Update is called once per frame
    void Update()
    {
        CheckDistance();
        if (Input.GetButton("Attack"))
        {
            Attack();
        }
        if(Input.GetButton("Throw"))
        {
            throwBomb();
        }
    }
    void CheckDistance()
    {
        isNear = checkZone.IsTouchingLayers(LayerMask.GetMask("Enemy"));
        anim.SetBool("isNear",isNear);
    }
    void Attack()
    {
        if (isNear)
        {
            if (nearCd)
            {
                anim.SetTrigger("Attack");
                nearCd = false;
                StartCoroutine(startAttack());

            }
        }
        else
        {
            shootZone.GetComponent<ArrowHit>().Shoot();
        }
    }

    void throwBomb()
    {
        shootZone.GetComponent<ArrowHit>().thowBomb();
    }

    IEnumerator disableMitbox()
    {
        yield return new WaitForSeconds(time);
        coll2D.enabled = false;
        nearCd = true;
    }
    IEnumerator startAttack()
    {
        yield return new WaitForSeconds(startTime);
        coll2D.enabled = true;
        StartCoroutine(disableMitbox());
    }

    void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Enemy"))
        {
            collision.GetComponent<Enemy>().takeDamage(damage);
        }
    }

}
