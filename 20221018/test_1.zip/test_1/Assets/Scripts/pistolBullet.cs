using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class pistolBullet : PlayerBullet
{
    // Start is called before the first frame update
    new protected void Start()
    {
        base.Start();
    }

    // Update is called once per frame
    new protected void Update()
    {
        base.Update();
    }
}
