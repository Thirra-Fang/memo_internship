using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerControl : MonoBehaviour
{
    public float runSpeed;
    public float jumpSpeed;
    public bool playerHasXAxisSpeed;
    public bool isGround;
    private Rigidbody2D myRigidbody;
    private Animator myAnim;
    private BoxCollider2D myFeet;
    // Start is called before the first frame update
    void Start()
    {
        myRigidbody = GetComponent<Rigidbody2D>();
        myAnim = GetComponent<Animator>();
        myFeet = GetComponent<BoxCollider2D>();
        playerHasXAxisSpeed = false;
    }

    // Update is called once per frame
    void Update()
    {
        Run();
        Flip();
        CheckGround();
        Jump();
    }
    
    void CheckGround()
    {
        isGround = myFeet.IsTouchingLayers(LayerMask.GetMask("Ground"));
        myAnim.SetBool("onground", isGround);
    }

    void Flip()
    {
        if (playerHasXAxisSpeed)
        {
            if (myRigidbody.velocity.x > 0.1f)
                transform.localRotation = Quaternion.Euler(0, 180, 0);

            if (myRigidbody.velocity.x < -0.1f)
                transform.localRotation = Quaternion.Euler(0, 0, 0);
        }
    }

    void Run()
    {
        float moveDir = Input.GetAxis("Horizontal");
        Vector2 playerVel = new Vector2(moveDir * runSpeed,myRigidbody.velocity.y);
        myRigidbody.velocity = playerVel;
        playerHasXAxisSpeed = Mathf.Abs(myRigidbody.velocity.x) > 0.1f;
        myAnim.SetBool("run", playerHasXAxisSpeed);
    }

    void Jump()
    {
        if (Input.GetButtonDown("Jump")&&isGround)
        {
            Vector2 jumpVel = new Vector2(0.0f, jumpSpeed);
            myRigidbody.velocity = Vector2.up * jumpVel;
        }
    }
}
