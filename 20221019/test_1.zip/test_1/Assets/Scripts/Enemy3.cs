using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy3 : Enemy
{
    public GameObject arrowProfab;
    public float attackPauseTime;
    public Transform[] movePos;
    public Transform cameral;



    private bool canShoot;
    private int i;
    private bool actived;
    // Start is called before the first frame update
    new void Start()
    {
        base.Start();
        canShoot = true;
        rb2D = GetComponent<Rigidbody2D>();
        i = 0;
        actived = false;
    }

    // Update is called once per frame
    new void Update()
    {
        base.Update();
        if (isActive)
        {
            Shoot();
            if ((!actived))
            {
                actived = true;
                transform.parent = cameral;
            }
            Move();
        }
    }
    void Shoot()
    {

        if (canShoot)
        {
            Instantiate(arrowProfab, transform.position, Quaternion.Euler(0,0,-90.0f)).transform.parent = cameral;
            StartCoroutine(AttackPause());
        }
    }
    IEnumerator AttackPause()
    {
        canShoot = false;
        yield return new WaitForSeconds(attackPauseTime);
        canShoot = true;
    }
    private void Move()
    {
        if (i < movePos.Length)
        {
            transform.localPosition = Vector3.MoveTowards(transform.localPosition, movePos[i].localPosition, speed * Time.deltaTime);
            if (Vector2.Distance(transform.position, movePos[i].position) < 0.1f)
            {
                i++;
            }
        }
        else if(i == movePos.Length)
        {
            i = 0;
        }
    }
}
