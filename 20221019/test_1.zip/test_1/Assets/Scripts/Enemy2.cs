using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy2 : Enemy
{
    public GameObject arrowProfab;
    public float attackPauseTime;
    public Vector2 initialSpeed;
    public float implicatedVelocity;

    private bool canShoot;
    private  Quaternion aimingRotation;
    // Start is called before the first frame update
    new void Start()
    {
        base.Start();
        canShoot = true;
        rb2D = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    new void Update()
    {
        base.Update();
        if (isActive)
        {

            Shoot();
            Aim();
            rb2D.velocity = initialSpeed;
        }
    }
    void Shoot()
    {
        if (canShoot)
        {
            Instantiate(arrowProfab, transform.position,aimingRotation).transform.parent = GameObject.FindGameObjectsWithTag("MainCamera")[0].transform;
            StartCoroutine(AttackPause());
        }
    }
    IEnumerator AttackPause()
    {
        canShoot = false;
        yield return new WaitForSeconds(attackPauseTime);
        canShoot = true;
    }
    void Aim()
    {
        transform.eulerAngles = new Vector3(0.0f, 90+90*(player.transform.position.x-transform.position.x)/Mathf.Abs(player.transform.position.x - transform.position.x), 0.0f);
        aimingRotation = Quaternion.Euler(0.0f, 270 + 90 * (player.transform.position.x - transform.position.x) / Mathf.Abs(player.transform.position.x - transform.position.x), (player.transform.position.x - transform.position.x) / Mathf.Abs(player.transform.position.x - transform.position.x)*180 /Mathf.PI*Mathf.Atan(player.transform.position.y-transform.position.y)/(player.transform.position.x-transform.position.x));
    }
}
