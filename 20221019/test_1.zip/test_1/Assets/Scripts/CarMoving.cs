using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CarMoving : MonoBehaviour
{
    public float speed;
    public Transform[] movePos;
    public Transform player;
    public Transform camera1;

    private int i;
    private bool begin;
    // Start is called before the first frame update
    void Start()
    {
        i = 0;
        begin = false;
    }

    // Update is called once per frame
    void Update()
    {
        Move();
        ignition();
    }
    void Move()
    {
        if (i < movePos.Length && begin)
        {
            transform.position = Vector2.MoveTowards(transform.position, movePos[i].position, speed * Time.deltaTime);
            if (Vector2.Distance(transform.position, movePos[i].position) < 0.1f)
            {
                i++;
            }
        }
    }
    public void ignition()
    {
        if (transform.GetComponent<BoxCollider2D>().IsTouchingLayers(LayerMask.GetMask("Player"))&&!begin)
        {

            begin = true;
            player.parent = transform;
            camera1.parent = transform;
            camera1.localPosition = camera1.localPosition + new Vector3(0, 1.7f);
        }
    }
}
